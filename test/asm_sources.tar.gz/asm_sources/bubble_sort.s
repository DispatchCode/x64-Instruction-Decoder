.intel_syntax noprefix
.text
.global bubble_sort
.type bubble_sort, @function

# void bubble_sort(int32_t *array, size_t length)
# System V AMD64 ABI: array in RDI, length in RSI.
# Sorts signed 32-bit integers in ascending order, in place.
bubble_sort:
    cmp     rsi, 1
    jbe     .done
    mov     rdx, rsi
    sub     rdx, 1

.outer:
    xor     ecx, ecx
.inner:
    mov     eax, dword ptr [rdi + rcx*4]
    mov     r9d, dword ptr [rdi + rcx*4 + 4]
    cmp     eax, r9d
    jle     .no_swap
    mov     dword ptr [rdi + rcx*4], r9d
    mov     dword ptr [rdi + rcx*4 + 4], eax
.no_swap:
    add     rcx, 1
    cmp     rcx, rdx
    jb      .inner
    sub     rdx, 1
    jnz     .outer
.done:
    ret

.size bubble_sort, .-bubble_sort
